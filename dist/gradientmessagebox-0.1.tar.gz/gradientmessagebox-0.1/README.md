# gradient message box
A very simple tkinter prompt window with a animated gradient background.
